self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b85dcc0a3c97ac180ac2605af03e8db2",
    "url": "localhost:5000/index.html"
  },
  {
    "revision": "1971dc419d8ff518cc3c",
    "url": "localhost:5000/static/css/15.fa4a79a6.chunk.css"
  },
  {
    "revision": "a3e92510cfb08d21ed1f",
    "url": "localhost:5000/static/css/3.7581a0bd.chunk.css"
  },
  {
    "revision": "cf0c92e9442023ccd542",
    "url": "localhost:5000/static/css/main.a669b2e9.chunk.css"
  },
  {
    "revision": "00bd6b56c6ef3b965b1e",
    "url": "localhost:5000/static/js/0.2ed10846.chunk.js"
  },
  {
    "revision": "77445fd42362a807f159",
    "url": "localhost:5000/static/js/10.4d3a1c31.chunk.js"
  },
  {
    "revision": "dca9b50ba5326515854a",
    "url": "localhost:5000/static/js/11.db8b129a.chunk.js"
  },
  {
    "revision": "1841312d71000eb912d4",
    "url": "localhost:5000/static/js/12.35105134.chunk.js"
  },
  {
    "revision": "d4677023858e94cfbbf3",
    "url": "localhost:5000/static/js/13.551638b4.chunk.js"
  },
  {
    "revision": "3484cd2d16fd40fe9dc5",
    "url": "localhost:5000/static/js/14.382865c5.chunk.js"
  },
  {
    "revision": "1971dc419d8ff518cc3c",
    "url": "localhost:5000/static/js/15.fd52a427.chunk.js"
  },
  {
    "revision": "201fe3f81da589233c94",
    "url": "localhost:5000/static/js/16.484f6988.chunk.js"
  },
  {
    "revision": "01487f989bd446d380e1",
    "url": "localhost:5000/static/js/17.d0023d5e.chunk.js"
  },
  {
    "revision": "58772b2efc36c0bbd4af",
    "url": "localhost:5000/static/js/18.3502d025.chunk.js"
  },
  {
    "revision": "dca6c21606e98cba192d",
    "url": "localhost:5000/static/js/19.ff29036f.chunk.js"
  },
  {
    "revision": "6ff5e998017715b12870",
    "url": "localhost:5000/static/js/20.88c57bd4.chunk.js"
  },
  {
    "revision": "655cb5c6d2bec0a1ebf8",
    "url": "localhost:5000/static/js/21.ef069fb8.chunk.js"
  },
  {
    "revision": "7c51780f18ce8c1736a4",
    "url": "localhost:5000/static/js/22.1681049f.chunk.js"
  },
  {
    "revision": "e9902031b726b32b4027",
    "url": "localhost:5000/static/js/23.e2d78f21.chunk.js"
  },
  {
    "revision": "f7b5f8da5f486c1a41cb",
    "url": "localhost:5000/static/js/24.77159c4a.chunk.js"
  },
  {
    "revision": "fd332a7765ba537debf3",
    "url": "localhost:5000/static/js/25.7f5e3197.chunk.js"
  },
  {
    "revision": "a3e92510cfb08d21ed1f",
    "url": "localhost:5000/static/js/3.01123099.chunk.js"
  },
  {
    "revision": "2f75796be17c878a1725",
    "url": "localhost:5000/static/js/4.d462c906.chunk.js"
  },
  {
    "revision": "cc106c8865028fb9fdd2",
    "url": "localhost:5000/static/js/5.8cefbfd4.chunk.js"
  },
  {
    "revision": "4fb04eb21e7c96e17378",
    "url": "localhost:5000/static/js/6.d50c9635.chunk.js"
  },
  {
    "revision": "4b688b660afbd7e5d329",
    "url": "localhost:5000/static/js/7.f9b08835.chunk.js"
  },
  {
    "revision": "d60b2286780cba515012",
    "url": "localhost:5000/static/js/8.5c5069f7.chunk.js"
  },
  {
    "revision": "ef7147a2811445ac1143",
    "url": "localhost:5000/static/js/9.446a5ff0.chunk.js"
  },
  {
    "revision": "cf0c92e9442023ccd542",
    "url": "localhost:5000/static/js/main.37e47b7c.chunk.js"
  },
  {
    "revision": "6402e7a7e0fb08b456a0",
    "url": "localhost:5000/static/js/runtime~main.7f249834.js"
  },
  {
    "revision": "0087dce419a7376eb06c837f740d31eb",
    "url": "localhost:5000/static/media/CoreUI-Icons-Linear-Free.0087dce4.woff"
  },
  {
    "revision": "089ab3c11c572362d088083c561cfa55",
    "url": "localhost:5000/static/media/CoreUI-Icons-Linear-Free.089ab3c1.eot"
  },
  {
    "revision": "1bc3764815bb391a16771c42c6e460ec",
    "url": "localhost:5000/static/media/CoreUI-Icons-Linear-Free.1bc37648.ttf"
  },
  {
    "revision": "4b57c6a5567c9ef09913983f82904faa",
    "url": "localhost:5000/static/media/CoreUI-Icons-Linear-Free.4b57c6a5.svg"
  },
  {
    "revision": "0cb0b9c589c0624c9c78dd3d83e946f6",
    "url": "localhost:5000/static/media/Simple-Line-Icons.0cb0b9c5.woff2"
  },
  {
    "revision": "2fe2efe63441d830b1acd106c1fe8734",
    "url": "localhost:5000/static/media/Simple-Line-Icons.2fe2efe6.svg"
  },
  {
    "revision": "78f07e2c2a535c26ef21d95e41bd7175",
    "url": "localhost:5000/static/media/Simple-Line-Icons.78f07e2c.woff"
  },
  {
    "revision": "d2285965fe34b05465047401b8595dd0",
    "url": "localhost:5000/static/media/Simple-Line-Icons.d2285965.ttf"
  },
  {
    "revision": "f33df365d6d0255b586f2920355e94d7",
    "url": "localhost:5000/static/media/Simple-Line-Icons.f33df365.eot"
  },
  {
    "revision": "486d25a79ba1ee551360a5d18bfe7a2e",
    "url": "localhost:5000/static/media/ad.486d25a7.svg"
  },
  {
    "revision": "4fc7c4c1505769826e43061122a9549d",
    "url": "localhost:5000/static/media/ad.4fc7c4c1.svg"
  },
  {
    "revision": "7847726d0663899a3e31b3e21b6d2b68",
    "url": "localhost:5000/static/media/ae.7847726d.svg"
  },
  {
    "revision": "9fd1fcbfedb5ace0e6e61a88b3fc3402",
    "url": "localhost:5000/static/media/ae.9fd1fcbf.svg"
  },
  {
    "revision": "26d0dcc74a1febaea3cf306686e1290b",
    "url": "localhost:5000/static/media/af.26d0dcc7.svg"
  },
  {
    "revision": "b040d0176a79dd3b732066c4959be347",
    "url": "localhost:5000/static/media/af.b040d017.svg"
  },
  {
    "revision": "53a600867bab3b2284da8445e7d9cc93",
    "url": "localhost:5000/static/media/ag.53a60086.svg"
  },
  {
    "revision": "5c33e55d155844898cddc1b33b3fb7eb",
    "url": "localhost:5000/static/media/ag.5c33e55d.svg"
  },
  {
    "revision": "2bb08d7d607bfc13c34c18c28dfbcf5f",
    "url": "localhost:5000/static/media/ai.2bb08d7d.svg"
  },
  {
    "revision": "7445e66f4bd50d3b016a7f86fa949d0b",
    "url": "localhost:5000/static/media/ai.7445e66f.svg"
  },
  {
    "revision": "01225bebffa3b3d92a5f0c9d553a3c9e",
    "url": "localhost:5000/static/media/al.01225beb.svg"
  },
  {
    "revision": "633e8642cac145652ccd7d445f14b40a",
    "url": "localhost:5000/static/media/al.633e8642.svg"
  },
  {
    "revision": "06509258e6113e2e0e54592337ac8171",
    "url": "localhost:5000/static/media/am.06509258.svg"
  },
  {
    "revision": "c86a9e1691e7ab36234a070301467f01",
    "url": "localhost:5000/static/media/am.c86a9e16.svg"
  },
  {
    "revision": "4e70ca93b1286e2d049fc0bf3e681e61",
    "url": "localhost:5000/static/media/ao.4e70ca93.svg"
  },
  {
    "revision": "8484ac5ace453f56e8562f5aaf18a5bc",
    "url": "localhost:5000/static/media/ao.8484ac5a.svg"
  },
  {
    "revision": "b95845ac31dcda104cf59a4948cd5035",
    "url": "localhost:5000/static/media/aq.b95845ac.svg"
  },
  {
    "revision": "c61dd4213d496831c11205c3687723c9",
    "url": "localhost:5000/static/media/aq.c61dd421.svg"
  },
  {
    "revision": "4d01e57804727af96e6b9c926f0b33b7",
    "url": "localhost:5000/static/media/ar.4d01e578.svg"
  },
  {
    "revision": "cab4b98a2a589b0fe7762a29ace6bcf2",
    "url": "localhost:5000/static/media/ar.cab4b98a.svg"
  },
  {
    "revision": "83064c6f65a1ebc67981caf7910485a6",
    "url": "localhost:5000/static/media/as.83064c6f.svg"
  },
  {
    "revision": "e753c5e98283ce2fc1cb3814b62ecc4e",
    "url": "localhost:5000/static/media/as.e753c5e9.svg"
  },
  {
    "revision": "7824152b6e660004d8323754e25476ac",
    "url": "localhost:5000/static/media/at.7824152b.svg"
  },
  {
    "revision": "dc2457a23381d13940918ec3f5aba250",
    "url": "localhost:5000/static/media/at.dc2457a2.svg"
  },
  {
    "revision": "37a544275a1a5fbbe0662dc634d7abd7",
    "url": "localhost:5000/static/media/au.37a54427.svg"
  },
  {
    "revision": "da96b2e8d07bf4acc3176d10417219d0",
    "url": "localhost:5000/static/media/au.da96b2e8.svg"
  },
  {
    "revision": "29aeb3f91f4da71e6766492ca2de716d",
    "url": "localhost:5000/static/media/aw.29aeb3f9.svg"
  },
  {
    "revision": "f159ec168ea083c41505dce64eb31923",
    "url": "localhost:5000/static/media/aw.f159ec16.svg"
  },
  {
    "revision": "1aaab70377fb8b75181cdf72b459e716",
    "url": "localhost:5000/static/media/ax.1aaab703.svg"
  },
  {
    "revision": "fdd00c438df18b3216076ae0e145673b",
    "url": "localhost:5000/static/media/ax.fdd00c43.svg"
  },
  {
    "revision": "0b4258df02490e0504d93c20984c467d",
    "url": "localhost:5000/static/media/az.0b4258df.svg"
  },
  {
    "revision": "451284cedf7277f87440e014c3c11557",
    "url": "localhost:5000/static/media/az.451284ce.svg"
  },
  {
    "revision": "71010dff44cc2c8dfb46906c7add051f",
    "url": "localhost:5000/static/media/ba.71010dff.svg"
  },
  {
    "revision": "a9dbadd71245f7d220448c10b6939fd1",
    "url": "localhost:5000/static/media/ba.a9dbadd7.svg"
  },
  {
    "revision": "7bd8b0ac4adce55a674f8579188e3339",
    "url": "localhost:5000/static/media/bb.7bd8b0ac.svg"
  },
  {
    "revision": "e08360acef490330a17ff317af323b86",
    "url": "localhost:5000/static/media/bb.e08360ac.svg"
  },
  {
    "revision": "5102bab03db6e13a165043eedab1e332",
    "url": "localhost:5000/static/media/bd.5102bab0.svg"
  },
  {
    "revision": "c4a1485f3606f93b55fa19d86ec3219c",
    "url": "localhost:5000/static/media/bd.c4a1485f.svg"
  },
  {
    "revision": "27d8ca49197f90010475d2b3646ce6b5",
    "url": "localhost:5000/static/media/be.27d8ca49.svg"
  },
  {
    "revision": "f1e78c8b3266b110a4a523c4cde8d7f2",
    "url": "localhost:5000/static/media/be.f1e78c8b.svg"
  },
  {
    "revision": "48eb94de0b25013f341693acc2abb3b2",
    "url": "localhost:5000/static/media/bf.48eb94de.svg"
  },
  {
    "revision": "9a958401fd126a3c08686ece9477cea3",
    "url": "localhost:5000/static/media/bf.9a958401.svg"
  },
  {
    "revision": "3d762564b2be000f52ca9038e8f42ad4",
    "url": "localhost:5000/static/media/bg.3d762564.svg"
  },
  {
    "revision": "7163fe7683bf09611884f33ebf512d6a",
    "url": "localhost:5000/static/media/bg.7163fe76.svg"
  },
  {
    "revision": "290519a3ed05bbfa54c4d8bd7490706a",
    "url": "localhost:5000/static/media/bh.290519a3.svg"
  },
  {
    "revision": "392927ca04d16448d14ec44908cc41c5",
    "url": "localhost:5000/static/media/bh.392927ca.svg"
  },
  {
    "revision": "3e29b35ccab81ed71fa4a38bcaca903b",
    "url": "localhost:5000/static/media/bi.3e29b35c.svg"
  },
  {
    "revision": "9b802ccabfab6dc5ddf8cb8fcf709fa0",
    "url": "localhost:5000/static/media/bi.9b802cca.svg"
  },
  {
    "revision": "148de921897066d0f2146606bb7d97ee",
    "url": "localhost:5000/static/media/bj.148de921.svg"
  },
  {
    "revision": "b6387659d755f8364b76c2bc8ca15d65",
    "url": "localhost:5000/static/media/bj.b6387659.svg"
  },
  {
    "revision": "38e27b684c0a7f079cc7e1762e5e1ade",
    "url": "localhost:5000/static/media/bl.38e27b68.svg"
  },
  {
    "revision": "4d724b8ec2c508cf9abf4abef61289bc",
    "url": "localhost:5000/static/media/bl.4d724b8e.svg"
  },
  {
    "revision": "a523291dab46eb5ea5696a5d3ad77a65",
    "url": "localhost:5000/static/media/bm.a523291d.svg"
  },
  {
    "revision": "ca26b6f54cd34e40839ccbfab782d8ec",
    "url": "localhost:5000/static/media/bm.ca26b6f5.svg"
  },
  {
    "revision": "4f010489273c99561205355c8fbe6d09",
    "url": "localhost:5000/static/media/bn.4f010489.svg"
  },
  {
    "revision": "80c35c4c3177156ff0e1caf84da15d9e",
    "url": "localhost:5000/static/media/bn.80c35c4c.svg"
  },
  {
    "revision": "c83fd441e19d431768ed732ce2f6b467",
    "url": "localhost:5000/static/media/bo.c83fd441.svg"
  },
  {
    "revision": "cd93219fe50df8d489de9f9e189adc24",
    "url": "localhost:5000/static/media/bo.cd93219f.svg"
  },
  {
    "revision": "b551016fbdf64b9d22f1c7b34a6a3a8d",
    "url": "localhost:5000/static/media/bq.b551016f.svg"
  },
  {
    "revision": "d6da2e848d831d87d51683d9340dbd38",
    "url": "localhost:5000/static/media/bq.d6da2e84.svg"
  },
  {
    "revision": "a82efeaff853f1cf8cf85c2d526c0d9e",
    "url": "localhost:5000/static/media/br.a82efeaf.svg"
  },
  {
    "revision": "c834cb5b54aadf9673f6cd32f5b163ee",
    "url": "localhost:5000/static/media/br.c834cb5b.svg"
  },
  {
    "revision": "6fe877e157af3feb09878e657d8ad1f7",
    "url": "localhost:5000/static/media/bs.6fe877e1.svg"
  },
  {
    "revision": "910d4bd079b869f493912f6959dc0d77",
    "url": "localhost:5000/static/media/bs.910d4bd0.svg"
  },
  {
    "revision": "acfa822b42353a0e163384d46298a1b1",
    "url": "localhost:5000/static/media/bt.acfa822b.svg"
  },
  {
    "revision": "e502aa33ba1facb42dc71770fcbf6bc3",
    "url": "localhost:5000/static/media/bt.e502aa33.svg"
  },
  {
    "revision": "07434a841ad80dc5ab4512c03a6bf947",
    "url": "localhost:5000/static/media/bv.07434a84.svg"
  },
  {
    "revision": "b70ab2f2a1fdb7d66f6870a4f243f843",
    "url": "localhost:5000/static/media/bv.b70ab2f2.svg"
  },
  {
    "revision": "d1585fdf351c0bcd56a04ab460d51b3c",
    "url": "localhost:5000/static/media/bw.d1585fdf.svg"
  },
  {
    "revision": "d9e5e45f7cabb9c0790ba95948c30609",
    "url": "localhost:5000/static/media/bw.d9e5e45f.svg"
  },
  {
    "revision": "26a195de8eed70c1be4afe687905189f",
    "url": "localhost:5000/static/media/by.26a195de.svg"
  },
  {
    "revision": "80b2d2dd15003da07957e37b5d7aef23",
    "url": "localhost:5000/static/media/by.80b2d2dd.svg"
  },
  {
    "revision": "510d2519e35c7735178e2785d1057b1e",
    "url": "localhost:5000/static/media/bz.510d2519.svg"
  },
  {
    "revision": "e7e7013d46d9e770ca3a3a6f6b9d1256",
    "url": "localhost:5000/static/media/bz.e7e7013d.svg"
  },
  {
    "revision": "5916ba94ac216d2e1c238c5327a4d236",
    "url": "localhost:5000/static/media/ca.5916ba94.svg"
  },
  {
    "revision": "ce1431089b9cba8ed19a763287a27bac",
    "url": "localhost:5000/static/media/ca.ce143108.svg"
  },
  {
    "revision": "722f0576fc03cb0b7dc0ac8cf979e3ce",
    "url": "localhost:5000/static/media/cc.722f0576.svg"
  },
  {
    "revision": "ecc0e32127e3e743df24051cd5a119dd",
    "url": "localhost:5000/static/media/cc.ecc0e321.svg"
  },
  {
    "revision": "b43f872e1441147e938995ee5a709e19",
    "url": "localhost:5000/static/media/cd.b43f872e.svg"
  },
  {
    "revision": "cd346cdc7caa416803025986e843a600",
    "url": "localhost:5000/static/media/cd.cd346cdc.svg"
  },
  {
    "revision": "1bc217dc2a400899db46ee10cdd913d8",
    "url": "localhost:5000/static/media/cf.1bc217dc.svg"
  },
  {
    "revision": "667c7a422ea1e92f971848ef8bb347ce",
    "url": "localhost:5000/static/media/cf.667c7a42.svg"
  },
  {
    "revision": "8373836c83f0ae012b428ab2308e4352",
    "url": "localhost:5000/static/media/cg.8373836c.svg"
  },
  {
    "revision": "c8c05bfe0d270cc8c717e7622fe46185",
    "url": "localhost:5000/static/media/cg.c8c05bfe.svg"
  },
  {
    "revision": "252c409ba2d2600aaf08946b9280b670",
    "url": "localhost:5000/static/media/ch.252c409b.svg"
  },
  {
    "revision": "9c26f60a63bf575c6b7be3eec11e3043",
    "url": "localhost:5000/static/media/ch.9c26f60a.svg"
  },
  {
    "revision": "26a62321690cd175f47305c05a55f409",
    "url": "localhost:5000/static/media/ci.26a62321.svg"
  },
  {
    "revision": "d939dcac611747f6857eb4b92cb14c8e",
    "url": "localhost:5000/static/media/ci.d939dcac.svg"
  },
  {
    "revision": "bd3a061cfdfb9a0c9e100e5d487b2477",
    "url": "localhost:5000/static/media/ck.bd3a061c.svg"
  },
  {
    "revision": "d66de29cda9f7872d1a346194e41643c",
    "url": "localhost:5000/static/media/ck.d66de29c.svg"
  },
  {
    "revision": "6d63ff70245fe5abcbf9ccc50cecf8c2",
    "url": "localhost:5000/static/media/cl.6d63ff70.svg"
  },
  {
    "revision": "7709f09f2086cc6f774c6a90fc56936a",
    "url": "localhost:5000/static/media/cl.7709f09f.svg"
  },
  {
    "revision": "5799ad4c126b0a6b1a3f01599f862ad2",
    "url": "localhost:5000/static/media/cm.5799ad4c.svg"
  },
  {
    "revision": "c972441e6e4522441d18c0390c143d32",
    "url": "localhost:5000/static/media/cm.c972441e.svg"
  },
  {
    "revision": "02c229de4d98ea1668384d2ed4cc558d",
    "url": "localhost:5000/static/media/cn.02c229de.svg"
  },
  {
    "revision": "a94c93941a4d8907fc2be5a61841c2b9",
    "url": "localhost:5000/static/media/cn.a94c9394.svg"
  },
  {
    "revision": "3b252a1a91262604a52801ec3dda088d",
    "url": "localhost:5000/static/media/co.3b252a1a.svg"
  },
  {
    "revision": "41244c207c1c8c92c0140d5fad3b08b1",
    "url": "localhost:5000/static/media/co.41244c20.svg"
  },
  {
    "revision": "657d7dbcfdeb67b9324dc45f99a1e17c",
    "url": "localhost:5000/static/media/cr.657d7dbc.svg"
  },
  {
    "revision": "7b4ebd50f5274e5bfca82408ca79c32d",
    "url": "localhost:5000/static/media/cr.7b4ebd50.svg"
  },
  {
    "revision": "0b42edabb93ec1c4862f441f4151996e",
    "url": "localhost:5000/static/media/cu.0b42edab.svg"
  },
  {
    "revision": "ff754a33d53402c4661515c94370dec7",
    "url": "localhost:5000/static/media/cu.ff754a33.svg"
  },
  {
    "revision": "20a8cfffe0e96905132967daae5e2578",
    "url": "localhost:5000/static/media/cv.20a8cfff.svg"
  },
  {
    "revision": "b50df3fb841396412190948312d54900",
    "url": "localhost:5000/static/media/cv.b50df3fb.svg"
  },
  {
    "revision": "6c845a30476494ef2a3426a01f11a865",
    "url": "localhost:5000/static/media/cw.6c845a30.svg"
  },
  {
    "revision": "a5487f569726e06687f0b49008a5318e",
    "url": "localhost:5000/static/media/cw.a5487f56.svg"
  },
  {
    "revision": "6f47bd14b8c7a627cf455b048be75994",
    "url": "localhost:5000/static/media/cx.6f47bd14.svg"
  },
  {
    "revision": "9faec396778b1eea7c912660ee7e5560",
    "url": "localhost:5000/static/media/cx.9faec396.svg"
  },
  {
    "revision": "1c8c05115b97c88502b683839f256b3d",
    "url": "localhost:5000/static/media/cy.1c8c0511.svg"
  },
  {
    "revision": "f0e266512201fe79b63b76ff41f034e6",
    "url": "localhost:5000/static/media/cy.f0e26651.svg"
  },
  {
    "revision": "052ec527b4bb18cd4e482c2c6a6ad4f6",
    "url": "localhost:5000/static/media/cz.052ec527.svg"
  },
  {
    "revision": "490443104ecbfc24e2580b16a4d811b7",
    "url": "localhost:5000/static/media/cz.49044310.svg"
  },
  {
    "revision": "3e726c2b6a59e6e4543c0a1534d93796",
    "url": "localhost:5000/static/media/de.3e726c2b.svg"
  },
  {
    "revision": "4d7bac3b0b9ab578b009c54fecd5d06f",
    "url": "localhost:5000/static/media/de.4d7bac3b.svg"
  },
  {
    "revision": "0c386d224ea283b79429a3097c055388",
    "url": "localhost:5000/static/media/dj.0c386d22.svg"
  },
  {
    "revision": "3cf620d9f1db1057948ca29c96d0221c",
    "url": "localhost:5000/static/media/dj.3cf620d9.svg"
  },
  {
    "revision": "d046fb5b6363db6e655b3c1011c6f779",
    "url": "localhost:5000/static/media/dk.d046fb5b.svg"
  },
  {
    "revision": "eb1416e02baeee91a39f721e871caf23",
    "url": "localhost:5000/static/media/dk.eb1416e0.svg"
  },
  {
    "revision": "2910f70a40909e4caedd1f0ade7fd40c",
    "url": "localhost:5000/static/media/dm.2910f70a.svg"
  },
  {
    "revision": "5966a127bf0ab8e0f6e3551fa7e54b73",
    "url": "localhost:5000/static/media/dm.5966a127.svg"
  },
  {
    "revision": "06e1cfe3c337fb27d7e55aecc3f1cfbb",
    "url": "localhost:5000/static/media/do.06e1cfe3.svg"
  },
  {
    "revision": "e31ff1fdfd0b527ed1b4038d89b9a8e0",
    "url": "localhost:5000/static/media/do.e31ff1fd.svg"
  },
  {
    "revision": "7c2261f0f9478d4df62a06afc7cd22d4",
    "url": "localhost:5000/static/media/dz.7c2261f0.svg"
  },
  {
    "revision": "dea7ef634f60d171b144bb0b6235cff0",
    "url": "localhost:5000/static/media/dz.dea7ef63.svg"
  },
  {
    "revision": "a12f3b495c5217f9f5826b62a557f18b",
    "url": "localhost:5000/static/media/ec.a12f3b49.svg"
  },
  {
    "revision": "e1ea3417b5d1b8e2e657ce8d630b7d85",
    "url": "localhost:5000/static/media/ec.e1ea3417.svg"
  },
  {
    "revision": "6088c9ceb092913b54d7235ee2e56f2c",
    "url": "localhost:5000/static/media/ee.6088c9ce.svg"
  },
  {
    "revision": "9e932a62565e7ddda05182b706b4e48f",
    "url": "localhost:5000/static/media/ee.9e932a62.svg"
  },
  {
    "revision": "4259fc9ef85ca62812dff66861ecc01a",
    "url": "localhost:5000/static/media/eg.4259fc9e.svg"
  },
  {
    "revision": "c39a7f7e272fb477e69712f5767a22e3",
    "url": "localhost:5000/static/media/eg.c39a7f7e.svg"
  },
  {
    "revision": "61674b9fd1c02414abde982aa277e9a0",
    "url": "localhost:5000/static/media/eh.61674b9f.svg"
  },
  {
    "revision": "7af606702cfc4e5a49b7cdd6e459500e",
    "url": "localhost:5000/static/media/eh.7af60670.svg"
  },
  {
    "revision": "976db2b72f1dcc39f35755b9ed945efb",
    "url": "localhost:5000/static/media/er.976db2b7.svg"
  },
  {
    "revision": "c9799558f7907ccbe07be65870c92631",
    "url": "localhost:5000/static/media/er.c9799558.svg"
  },
  {
    "revision": "46e9ce9e95b5b9c125e2a707cc5fcce9",
    "url": "localhost:5000/static/media/es-ct.46e9ce9e.svg"
  },
  {
    "revision": "9429ea9cc9f9eae02e83fa174a4b9021",
    "url": "localhost:5000/static/media/es-ct.9429ea9c.svg"
  },
  {
    "revision": "cc1b41b0e9485796cebb98fb04a7c10e",
    "url": "localhost:5000/static/media/es.cc1b41b0.svg"
  },
  {
    "revision": "d18de46b69ab3e7efb07840699cd31a4",
    "url": "localhost:5000/static/media/es.d18de46b.svg"
  },
  {
    "revision": "2c1adbb55f047445e01c6714ff4556e3",
    "url": "localhost:5000/static/media/et.2c1adbb5.svg"
  },
  {
    "revision": "919059a46d59bd47f6ad9dbb6f9a1847",
    "url": "localhost:5000/static/media/et.919059a4.svg"
  },
  {
    "revision": "4c73f57cb89b48ebae5e4d8be33e83b8",
    "url": "localhost:5000/static/media/eu.4c73f57c.svg"
  },
  {
    "revision": "ee7f4712ac4553621d85503cb9a130e5",
    "url": "localhost:5000/static/media/eu.ee7f4712.svg"
  },
  {
    "revision": "2649533e1d44a2ef75d5679ef6839b9e",
    "url": "localhost:5000/static/media/fi.2649533e.svg"
  },
  {
    "revision": "b48413bec5778656a773aab237f031a4",
    "url": "localhost:5000/static/media/fi.b48413be.svg"
  },
  {
    "revision": "3e230d8e827f6c2cccb0a0a02cec3ed5",
    "url": "localhost:5000/static/media/fj.3e230d8e.svg"
  },
  {
    "revision": "7cc3769d5415c64f7e14b49f68054e20",
    "url": "localhost:5000/static/media/fj.7cc3769d.svg"
  },
  {
    "revision": "2d1b653b364be637310ad1a9bacac160",
    "url": "localhost:5000/static/media/fk.2d1b653b.svg"
  },
  {
    "revision": "dd7bc357e2bee86baca858ecccb78593",
    "url": "localhost:5000/static/media/fk.dd7bc357.svg"
  },
  {
    "revision": "2b14fecb01ff1af11129008a123f4713",
    "url": "localhost:5000/static/media/fm.2b14fecb.svg"
  },
  {
    "revision": "3f19d612c1d987a0948edbf753d9b96f",
    "url": "localhost:5000/static/media/fm.3f19d612.svg"
  },
  {
    "revision": "329cbed566020b8e0d7a7b87fe977d28",
    "url": "localhost:5000/static/media/fo.329cbed5.svg"
  },
  {
    "revision": "b08620b37d2f4e306b5f687e63b0a8ab",
    "url": "localhost:5000/static/media/fo.b08620b3.svg"
  },
  {
    "revision": "674f50d287a8c48dc19ba404d20fe713",
    "url": "localhost:5000/static/media/fontawesome-webfont.674f50d2.eot"
  },
  {
    "revision": "912ec66d7572ff821749319396470bde",
    "url": "localhost:5000/static/media/fontawesome-webfont.912ec66d.svg"
  },
  {
    "revision": "af7ae505a9eed503f8b8e6982036873e",
    "url": "localhost:5000/static/media/fontawesome-webfont.af7ae505.woff2"
  },
  {
    "revision": "b06871f281fee6b241d60582ae9369b9",
    "url": "localhost:5000/static/media/fontawesome-webfont.b06871f2.ttf"
  },
  {
    "revision": "fee66e712a8a08eef5805a46892932ad",
    "url": "localhost:5000/static/media/fontawesome-webfont.fee66e71.woff"
  },
  {
    "revision": "b1156355de9691d768df19a8a2b44da4",
    "url": "localhost:5000/static/media/fr.b1156355.svg"
  },
  {
    "revision": "f8952213641bba462c7314007909d394",
    "url": "localhost:5000/static/media/fr.f8952213.svg"
  },
  {
    "revision": "29f203bb2828c1aed048b446c8abb0ae",
    "url": "localhost:5000/static/media/ga.29f203bb.svg"
  },
  {
    "revision": "33d27fe1d14e7a989255f6c1d24e5882",
    "url": "localhost:5000/static/media/ga.33d27fe1.svg"
  },
  {
    "revision": "14167f77f128b0f57a6263843017fc0f",
    "url": "localhost:5000/static/media/gb-eng.14167f77.svg"
  },
  {
    "revision": "eabfeadc28e73c627eb8c65999d93aae",
    "url": "localhost:5000/static/media/gb-eng.eabfeadc.svg"
  },
  {
    "revision": "42b69bbde9298fb21d4c2ce03c2218a0",
    "url": "localhost:5000/static/media/gb-nir.42b69bbd.svg"
  },
  {
    "revision": "5b44fea7baad0f213d7dfddb0c789423",
    "url": "localhost:5000/static/media/gb-nir.5b44fea7.svg"
  },
  {
    "revision": "31ef8bcf9416bbd5b8c6ef29d1411e5f",
    "url": "localhost:5000/static/media/gb-sct.31ef8bcf.svg"
  },
  {
    "revision": "4c2c379f607fe46e0cec999154ea0ba8",
    "url": "localhost:5000/static/media/gb-sct.4c2c379f.svg"
  },
  {
    "revision": "8742b3d61adec7352b6e56cb8c8b7856",
    "url": "localhost:5000/static/media/gb-wls.8742b3d6.svg"
  },
  {
    "revision": "ca26c224b36b361e8433c2ecf1b5a0e2",
    "url": "localhost:5000/static/media/gb-wls.ca26c224.svg"
  },
  {
    "revision": "4f1b7af5c0bae6aae85c3e7ba9401a85",
    "url": "localhost:5000/static/media/gb.4f1b7af5.svg"
  },
  {
    "revision": "50f7fd14ca63b8b05bdbf0554a5092d8",
    "url": "localhost:5000/static/media/gb.50f7fd14.svg"
  },
  {
    "revision": "3c05bb4957011ec7d56f913e1bd9d4d5",
    "url": "localhost:5000/static/media/gd.3c05bb49.svg"
  },
  {
    "revision": "b402c8c6fdfc7cab982e8fb011413fd9",
    "url": "localhost:5000/static/media/gd.b402c8c6.svg"
  },
  {
    "revision": "292fa4585c8ab314c207c401fac8996f",
    "url": "localhost:5000/static/media/ge.292fa458.svg"
  },
  {
    "revision": "5f68e7f370e90338682ffa228db024a2",
    "url": "localhost:5000/static/media/ge.5f68e7f3.svg"
  },
  {
    "revision": "23d8b419461e2b4bec1aa799ecef34bf",
    "url": "localhost:5000/static/media/gf.23d8b419.svg"
  },
  {
    "revision": "2ab15edf97187860137f7b508981965a",
    "url": "localhost:5000/static/media/gf.2ab15edf.svg"
  },
  {
    "revision": "357e1e33666fb0844d0416d5b0879d57",
    "url": "localhost:5000/static/media/gg.357e1e33.svg"
  },
  {
    "revision": "98f67a6ff36afda7a5ec44ec59eb5033",
    "url": "localhost:5000/static/media/gg.98f67a6f.svg"
  },
  {
    "revision": "77872d15b6a675d391e8355c98f9c020",
    "url": "localhost:5000/static/media/gh.77872d15.svg"
  },
  {
    "revision": "caedb9129bf6bd63ff4081a0ba91e113",
    "url": "localhost:5000/static/media/gh.caedb912.svg"
  },
  {
    "revision": "6ecace1817c2609b2a9baaac4fa04715",
    "url": "localhost:5000/static/media/gi.6ecace18.svg"
  },
  {
    "revision": "e829d66edd3fc4e28c3c969e6a9d1ec2",
    "url": "localhost:5000/static/media/gi.e829d66e.svg"
  },
  {
    "revision": "28a07cffa1bb4b3152f32912c867ef1e",
    "url": "localhost:5000/static/media/gl.28a07cff.svg"
  },
  {
    "revision": "28bf64e497ad74bc4ea1dcb1cc8a69bd",
    "url": "localhost:5000/static/media/gl.28bf64e4.svg"
  },
  {
    "revision": "414139d5039a0584ac0475034a3ad8c7",
    "url": "localhost:5000/static/media/gm.414139d5.svg"
  },
  {
    "revision": "f06a98cd5c0b07d6c3d0d7cc2f6a40b8",
    "url": "localhost:5000/static/media/gm.f06a98cd.svg"
  },
  {
    "revision": "1ce64523708a4513c00768eced01f5d5",
    "url": "localhost:5000/static/media/gn.1ce64523.svg"
  },
  {
    "revision": "36a3e9a3dd82736bfcf23f28bb3ebc10",
    "url": "localhost:5000/static/media/gn.36a3e9a3.svg"
  },
  {
    "revision": "c2c4da0e6afbe97dffaa2ee25972ae72",
    "url": "localhost:5000/static/media/gp.c2c4da0e.svg"
  },
  {
    "revision": "fa4cab3e4ee1b865a975e5eb6ab70d03",
    "url": "localhost:5000/static/media/gp.fa4cab3e.svg"
  },
  {
    "revision": "0c1057b34b46bc63471a9a62d3febb5d",
    "url": "localhost:5000/static/media/gq.0c1057b3.svg"
  },
  {
    "revision": "385ac47e2485d7dfb0bcdac986bc6cb0",
    "url": "localhost:5000/static/media/gq.385ac47e.svg"
  },
  {
    "revision": "6911d46028b1431a16071c70cd9a166e",
    "url": "localhost:5000/static/media/gr.6911d460.svg"
  },
  {
    "revision": "db77f48c7f332561c119c5b644c2247a",
    "url": "localhost:5000/static/media/gr.db77f48c.svg"
  },
  {
    "revision": "175a61d9f7540ab6d862966fe40cfd60",
    "url": "localhost:5000/static/media/gs.175a61d9.svg"
  },
  {
    "revision": "1def7829b26a04ff77d34753077427b1",
    "url": "localhost:5000/static/media/gs.1def7829.svg"
  },
  {
    "revision": "58f35af655d658aced08074bbc676a8c",
    "url": "localhost:5000/static/media/gt.58f35af6.svg"
  },
  {
    "revision": "7fe64e01367794301fee1af548f1f1e8",
    "url": "localhost:5000/static/media/gt.7fe64e01.svg"
  },
  {
    "revision": "243ab68e3dca89514d9aa5d4fa9cca97",
    "url": "localhost:5000/static/media/gu.243ab68e.svg"
  },
  {
    "revision": "d0da25e7e2c4f411345e9e63c88e6cbf",
    "url": "localhost:5000/static/media/gu.d0da25e7.svg"
  },
  {
    "revision": "5ecbd93cc2eeec1d063377170a3d83ee",
    "url": "localhost:5000/static/media/gw.5ecbd93c.svg"
  },
  {
    "revision": "c1e88a916be1c72f688c9e488cdd4516",
    "url": "localhost:5000/static/media/gw.c1e88a91.svg"
  },
  {
    "revision": "0653b318bc72188902840668e70e269f",
    "url": "localhost:5000/static/media/gy.0653b318.svg"
  },
  {
    "revision": "79fcf270400edca30d7790872057d26c",
    "url": "localhost:5000/static/media/gy.79fcf270.svg"
  },
  {
    "revision": "9502d7167e62fb1be4becfc187f16989",
    "url": "localhost:5000/static/media/hk.9502d716.svg"
  },
  {
    "revision": "e671691512658bbbc7bfeffca43fe086",
    "url": "localhost:5000/static/media/hk.e6716915.svg"
  },
  {
    "revision": "fc838ac0bb4f5ff27231f59d9480f842",
    "url": "localhost:5000/static/media/hm.fc838ac0.svg"
  },
  {
    "revision": "fe514431ce7922c28d2d322faa28b7f6",
    "url": "localhost:5000/static/media/hm.fe514431.svg"
  },
  {
    "revision": "9b9bee13c67ab85cd468d1c5fe38ad3e",
    "url": "localhost:5000/static/media/hn.9b9bee13.svg"
  },
  {
    "revision": "c94622ad395a0173231ae8ac41bf45a4",
    "url": "localhost:5000/static/media/hn.c94622ad.svg"
  },
  {
    "revision": "8f6905ab9a3f09b7ad72e4d6772e2223",
    "url": "localhost:5000/static/media/hr.8f6905ab.svg"
  },
  {
    "revision": "d01a1866ccd70d013c40d4832ab3f02e",
    "url": "localhost:5000/static/media/hr.d01a1866.svg"
  },
  {
    "revision": "18b350ac2dd74dfb68c13c01f3740620",
    "url": "localhost:5000/static/media/ht.18b350ac.svg"
  },
  {
    "revision": "a0b173aaef73a37242b23ee59ac0609a",
    "url": "localhost:5000/static/media/ht.a0b173aa.svg"
  },
  {
    "revision": "0d7409f88bca8325938e46e3ef672716",
    "url": "localhost:5000/static/media/hu.0d7409f8.svg"
  },
  {
    "revision": "e5e334fdd028898fe762fe6b9d47b6f1",
    "url": "localhost:5000/static/media/hu.e5e334fd.svg"
  },
  {
    "revision": "17b996767ee0373a262c32a16248a3b6",
    "url": "localhost:5000/static/media/id.17b99676.svg"
  },
  {
    "revision": "9f708fe5bf604f5bf38ad5ca2c00c14b",
    "url": "localhost:5000/static/media/id.9f708fe5.svg"
  },
  {
    "revision": "798a56e04350344c5937927fea36fabc",
    "url": "localhost:5000/static/media/ie.798a56e0.svg"
  },
  {
    "revision": "c68ff961baf04c04f9beac2c32cd2458",
    "url": "localhost:5000/static/media/ie.c68ff961.svg"
  },
  {
    "revision": "c36a011de460eb2d3b8c5674b9496d45",
    "url": "localhost:5000/static/media/il.c36a011d.svg"
  },
  {
    "revision": "f62b32f0be82b0a6d6942467ca871fa8",
    "url": "localhost:5000/static/media/il.f62b32f0.svg"
  },
  {
    "revision": "6cf57263ebd4071f3af5c61b08855597",
    "url": "localhost:5000/static/media/im.6cf57263.svg"
  },
  {
    "revision": "ed29d9ff19c46202628ebd71cdb4f0ef",
    "url": "localhost:5000/static/media/im.ed29d9ff.svg"
  },
  {
    "revision": "209ae8e9585774eb4fe32c001f7c63cc",
    "url": "localhost:5000/static/media/in.209ae8e9.svg"
  },
  {
    "revision": "e4ab7bd057c6d49f21b3460a1bf914a9",
    "url": "localhost:5000/static/media/in.e4ab7bd0.svg"
  },
  {
    "revision": "2d90626cf903f5aa04980cc208d6e342",
    "url": "localhost:5000/static/media/io.2d90626c.svg"
  },
  {
    "revision": "550553a764e49600498f1d17cd42da40",
    "url": "localhost:5000/static/media/io.550553a7.svg"
  },
  {
    "revision": "30dee02831c80a89cb49b94e7d6e6209",
    "url": "localhost:5000/static/media/iq.30dee028.svg"
  },
  {
    "revision": "e1922026e8c0bedf3b61e1e214f098b4",
    "url": "localhost:5000/static/media/iq.e1922026.svg"
  },
  {
    "revision": "717422e60d025fa48a0b7460792cdcbf",
    "url": "localhost:5000/static/media/ir.717422e6.svg"
  },
  {
    "revision": "9023419c73718709ef9631a6303991a8",
    "url": "localhost:5000/static/media/ir.9023419c.svg"
  },
  {
    "revision": "ae44c07e894b0a298c57b1380c5c11be",
    "url": "localhost:5000/static/media/is.ae44c07e.svg"
  },
  {
    "revision": "cff140f41d09ba1961eb5e6fd9f36331",
    "url": "localhost:5000/static/media/is.cff140f4.svg"
  },
  {
    "revision": "22b99ae704f3de63285bc9b9411c5031",
    "url": "localhost:5000/static/media/it.22b99ae7.svg"
  },
  {
    "revision": "8d15de04f5f6e8e89cab4e5eb237f607",
    "url": "localhost:5000/static/media/it.8d15de04.svg"
  },
  {
    "revision": "2026b139288b127cab015ff45ee5da76",
    "url": "localhost:5000/static/media/je.2026b139.svg"
  },
  {
    "revision": "862cd38b23ba01053db49d0e3f063b30",
    "url": "localhost:5000/static/media/je.862cd38b.svg"
  },
  {
    "revision": "67f96b2f0df34ce53d7651ade04d1e0b",
    "url": "localhost:5000/static/media/jm.67f96b2f.svg"
  },
  {
    "revision": "b7b13124a4068892dc2452d744a42cc1",
    "url": "localhost:5000/static/media/jm.b7b13124.svg"
  },
  {
    "revision": "118c5546136b7d67daa584332e9c15ed",
    "url": "localhost:5000/static/media/jo.118c5546.svg"
  },
  {
    "revision": "5130279865a7759012e11ea127f87f9d",
    "url": "localhost:5000/static/media/jo.51302798.svg"
  },
  {
    "revision": "95c2abfe2fa7c438741349c18ee3a976",
    "url": "localhost:5000/static/media/jp.95c2abfe.svg"
  },
  {
    "revision": "ae89446a56bc49a83f0947772c68adc5",
    "url": "localhost:5000/static/media/jp.ae89446a.svg"
  },
  {
    "revision": "0bbfd05193b7ca75f1b75e33fbb48c53",
    "url": "localhost:5000/static/media/ke.0bbfd051.svg"
  },
  {
    "revision": "1c54a4899948c14d27f59aa67622a729",
    "url": "localhost:5000/static/media/ke.1c54a489.svg"
  },
  {
    "revision": "c6895000555d24749137f2a92513af1e",
    "url": "localhost:5000/static/media/kg.c6895000.svg"
  },
  {
    "revision": "e588babc47e6eb59d65bf06527d7d004",
    "url": "localhost:5000/static/media/kg.e588babc.svg"
  },
  {
    "revision": "25b4be5d47e920ba3a1057a3d13d52b2",
    "url": "localhost:5000/static/media/kh.25b4be5d.svg"
  },
  {
    "revision": "7f27fa7392df9f355609b77c216192c1",
    "url": "localhost:5000/static/media/kh.7f27fa73.svg"
  },
  {
    "revision": "bf675826e286eeb617c7368b9caca2b3",
    "url": "localhost:5000/static/media/ki.bf675826.svg"
  },
  {
    "revision": "ca42f7e38b41cb0e0f04ee01c97f2dac",
    "url": "localhost:5000/static/media/ki.ca42f7e3.svg"
  },
  {
    "revision": "0f12d30cd1bc75d3d38768f1aa7d4d90",
    "url": "localhost:5000/static/media/km.0f12d30c.svg"
  },
  {
    "revision": "e0df62e410baf1d711869d58f0d8eaa6",
    "url": "localhost:5000/static/media/km.e0df62e4.svg"
  },
  {
    "revision": "4ad12564dce8cd72eac5f2761c8bf03d",
    "url": "localhost:5000/static/media/kn.4ad12564.svg"
  },
  {
    "revision": "b0fd5e10c0f172cd3cb36b93dda2d585",
    "url": "localhost:5000/static/media/kn.b0fd5e10.svg"
  },
  {
    "revision": "07ebeb5c6be5c8f85ba2bff84abda65d",
    "url": "localhost:5000/static/media/kp.07ebeb5c.svg"
  },
  {
    "revision": "f08daf335790f99ff297feab4ed1dcec",
    "url": "localhost:5000/static/media/kp.f08daf33.svg"
  },
  {
    "revision": "68586ef8dee277d9cf13d0d9a2715b02",
    "url": "localhost:5000/static/media/kr.68586ef8.svg"
  },
  {
    "revision": "6d3d963fd85ce15d80cc7dd3ed6f0b52",
    "url": "localhost:5000/static/media/kr.6d3d963f.svg"
  },
  {
    "revision": "0d0ac54c4acaab7536baee3de6fbee11",
    "url": "localhost:5000/static/media/kw.0d0ac54c.svg"
  },
  {
    "revision": "33b3292eb3089a10a5cb93cfda9efda2",
    "url": "localhost:5000/static/media/kw.33b3292e.svg"
  },
  {
    "revision": "7a1c98fc66b1959ad6cdb286069cde39",
    "url": "localhost:5000/static/media/ky.7a1c98fc.svg"
  },
  {
    "revision": "93a85a5572efe8d2f51df2e2853f7bf3",
    "url": "localhost:5000/static/media/ky.93a85a55.svg"
  },
  {
    "revision": "156c054bd0432d52e81d7b5bdccb3ee3",
    "url": "localhost:5000/static/media/kz.156c054b.svg"
  },
  {
    "revision": "d37cbd6165219d5bf58b37787d7acdbd",
    "url": "localhost:5000/static/media/kz.d37cbd61.svg"
  },
  {
    "revision": "562dda7446562f8135467380261eaec5",
    "url": "localhost:5000/static/media/la.562dda74.svg"
  },
  {
    "revision": "b61549ab9a32b7ce90b879b197dfbb4d",
    "url": "localhost:5000/static/media/la.b61549ab.svg"
  },
  {
    "revision": "23f85946df6ad8b8700c224a292056e9",
    "url": "localhost:5000/static/media/lb.23f85946.svg"
  },
  {
    "revision": "8e9c186c24f3fed17b0bee1c30f57bbe",
    "url": "localhost:5000/static/media/lb.8e9c186c.svg"
  },
  {
    "revision": "1c3a5554a0d8d1afaaf56164415da91c",
    "url": "localhost:5000/static/media/lc.1c3a5554.svg"
  },
  {
    "revision": "c056c2a721c5bd992bd4945d10f82541",
    "url": "localhost:5000/static/media/lc.c056c2a7.svg"
  },
  {
    "revision": "7787a5f8f647a73a6973bd15d4e45523",
    "url": "localhost:5000/static/media/li.7787a5f8.svg"
  },
  {
    "revision": "9e40c74ae0f4cc1c48321772ac1d4981",
    "url": "localhost:5000/static/media/li.9e40c74a.svg"
  },
  {
    "revision": "96cf4c4f16a30890687d4b101369e497",
    "url": "localhost:5000/static/media/lk.96cf4c4f.svg"
  },
  {
    "revision": "bf15b308ab139ff72d9204219b59fd0d",
    "url": "localhost:5000/static/media/lk.bf15b308.svg"
  },
  {
    "revision": "537211e7dfab145efb2185260aded04d",
    "url": "localhost:5000/static/media/logo.537211e7.svg"
  },
  {
    "revision": "039251e3b986c21ad72336c16b0cf940",
    "url": "localhost:5000/static/media/lr.039251e3.svg"
  },
  {
    "revision": "6656f943933fa3febede9e123fdfbc73",
    "url": "localhost:5000/static/media/lr.6656f943.svg"
  },
  {
    "revision": "533cb320083af55b894a7bbe12cf015c",
    "url": "localhost:5000/static/media/ls.533cb320.svg"
  },
  {
    "revision": "c0799ebf1d583d0d38408484bb56ec44",
    "url": "localhost:5000/static/media/ls.c0799ebf.svg"
  },
  {
    "revision": "70975be09055c7db032d5a56a452d5d5",
    "url": "localhost:5000/static/media/lt.70975be0.svg"
  },
  {
    "revision": "c3aeac0dad1dfcc917a721a975ea29dd",
    "url": "localhost:5000/static/media/lt.c3aeac0d.svg"
  },
  {
    "revision": "2585715a069b9b8234825e2ce1ef8ed6",
    "url": "localhost:5000/static/media/lu.2585715a.svg"
  },
  {
    "revision": "c858787cf95b92f694dbe1d296a8a5d4",
    "url": "localhost:5000/static/media/lu.c858787c.svg"
  },
  {
    "revision": "8b293d984cea7db72e62598083dc759d",
    "url": "localhost:5000/static/media/lv.8b293d98.svg"
  },
  {
    "revision": "f3c1274d166407a222fa7326129821b7",
    "url": "localhost:5000/static/media/lv.f3c1274d.svg"
  },
  {
    "revision": "8b64bcbd55eb077964963c5501c4efc6",
    "url": "localhost:5000/static/media/ly.8b64bcbd.svg"
  },
  {
    "revision": "ae438f5a0664546bd81c71a56a0275be",
    "url": "localhost:5000/static/media/ly.ae438f5a.svg"
  },
  {
    "revision": "60fbc221d84de9fb44f0d70882a393fc",
    "url": "localhost:5000/static/media/ma.60fbc221.svg"
  },
  {
    "revision": "bee9c05416fd66f6bc4434f6d721bcac",
    "url": "localhost:5000/static/media/ma.bee9c054.svg"
  },
  {
    "revision": "78528abed80a64294f9a7141e62a394f",
    "url": "localhost:5000/static/media/mc.78528abe.svg"
  },
  {
    "revision": "b4f4b90da30103ef9cb0554e0111ea0d",
    "url": "localhost:5000/static/media/mc.b4f4b90d.svg"
  },
  {
    "revision": "63bbfb2eaec4d73ec13a52ad14dfbd18",
    "url": "localhost:5000/static/media/md.63bbfb2e.svg"
  },
  {
    "revision": "8f2e0071fcabb0ad40b65185ec76d5f0",
    "url": "localhost:5000/static/media/md.8f2e0071.svg"
  },
  {
    "revision": "8096e4aa56b12c0d56d10b1ba8e17f10",
    "url": "localhost:5000/static/media/me.8096e4aa.svg"
  },
  {
    "revision": "a0dbae6fcc7fe3946c553730b93725c8",
    "url": "localhost:5000/static/media/me.a0dbae6f.svg"
  },
  {
    "revision": "487f7bd7fd30eec81e74e5cf1f699833",
    "url": "localhost:5000/static/media/mf.487f7bd7.svg"
  },
  {
    "revision": "5b9ff36c7fed044c253162373820d80a",
    "url": "localhost:5000/static/media/mf.5b9ff36c.svg"
  },
  {
    "revision": "67f5922d788548be9d4900bebf2b5e63",
    "url": "localhost:5000/static/media/mg.67f5922d.svg"
  },
  {
    "revision": "91e10ba084cc7f7b2498ce81f9680a84",
    "url": "localhost:5000/static/media/mg.91e10ba0.svg"
  },
  {
    "revision": "6d60cee3ee8d6bee9a372599dea4a426",
    "url": "localhost:5000/static/media/mh.6d60cee3.svg"
  },
  {
    "revision": "8f1f91348e69c8bf64d85e59272d6349",
    "url": "localhost:5000/static/media/mh.8f1f9134.svg"
  },
  {
    "revision": "2413b10706c9e29c439b0dcf94ec8cfe",
    "url": "localhost:5000/static/media/mk.2413b107.svg"
  },
  {
    "revision": "ed091b887cafb2adbf04a411d7ac40fa",
    "url": "localhost:5000/static/media/mk.ed091b88.svg"
  },
  {
    "revision": "204b0da4b499bc3694416d547a8fa0c0",
    "url": "localhost:5000/static/media/ml.204b0da4.svg"
  },
  {
    "revision": "e6f097f93a69b28225c43e25fdcaf709",
    "url": "localhost:5000/static/media/ml.e6f097f9.svg"
  },
  {
    "revision": "8d6d26bc590adff8e84dc5a3342a2bfc",
    "url": "localhost:5000/static/media/mm.8d6d26bc.svg"
  },
  {
    "revision": "92e9f832a28fd293035e21d9b6983790",
    "url": "localhost:5000/static/media/mm.92e9f832.svg"
  },
  {
    "revision": "3995293775c1a1837f0517594a205182",
    "url": "localhost:5000/static/media/mn.39952937.svg"
  },
  {
    "revision": "b6529a3b13ea5080793aac3f2310c297",
    "url": "localhost:5000/static/media/mn.b6529a3b.svg"
  },
  {
    "revision": "1f249f5176c0bb29ed367559d4faabd2",
    "url": "localhost:5000/static/media/mo.1f249f51.svg"
  },
  {
    "revision": "44f9c5552cf0d423c84ae0625cc2791f",
    "url": "localhost:5000/static/media/mo.44f9c555.svg"
  },
  {
    "revision": "2671eebebb38b8e05f01e208125a2a56",
    "url": "localhost:5000/static/media/mp.2671eebe.svg"
  },
  {
    "revision": "aa6f2a40fea9a33e788546e0d0536e02",
    "url": "localhost:5000/static/media/mp.aa6f2a40.svg"
  },
  {
    "revision": "a09e48650a204ba97073a30c5510f63f",
    "url": "localhost:5000/static/media/mq.a09e4865.svg"
  },
  {
    "revision": "bfeadb02a0e0566b376450d23682c523",
    "url": "localhost:5000/static/media/mq.bfeadb02.svg"
  },
  {
    "revision": "a3c31876aadbd5083efc027fe44f3004",
    "url": "localhost:5000/static/media/mr.a3c31876.svg"
  },
  {
    "revision": "b293ed8922aead7af253e20fd0f51a1e",
    "url": "localhost:5000/static/media/mr.b293ed89.svg"
  },
  {
    "revision": "058b028b04940b18ad8489ceab227aa9",
    "url": "localhost:5000/static/media/ms.058b028b.svg"
  },
  {
    "revision": "d5390a0cb1e74972fee66b17765915d4",
    "url": "localhost:5000/static/media/ms.d5390a0c.svg"
  },
  {
    "revision": "51f074ae3fd129831ce090b23936bb34",
    "url": "localhost:5000/static/media/mt.51f074ae.svg"
  },
  {
    "revision": "fd8576042757f9d905d0a7b53e96c003",
    "url": "localhost:5000/static/media/mt.fd857604.svg"
  },
  {
    "revision": "67c8f3621446645a9008ef039b0dbc69",
    "url": "localhost:5000/static/media/mu.67c8f362.svg"
  },
  {
    "revision": "896330b72092b57179e09d43f831211b",
    "url": "localhost:5000/static/media/mu.896330b7.svg"
  },
  {
    "revision": "0fdc08c6985e30f2a3bfd6b5069c6757",
    "url": "localhost:5000/static/media/mv.0fdc08c6.svg"
  },
  {
    "revision": "3c896bfdad2f76fe0945fe43d776a9ab",
    "url": "localhost:5000/static/media/mv.3c896bfd.svg"
  },
  {
    "revision": "290d49f1d0a391614960ce24723aa5ea",
    "url": "localhost:5000/static/media/mw.290d49f1.svg"
  },
  {
    "revision": "59519962a87a994a082dbe67037a5320",
    "url": "localhost:5000/static/media/mw.59519962.svg"
  },
  {
    "revision": "cb47c8bfd8d9a04cb0d8ae2617a84d3f",
    "url": "localhost:5000/static/media/mx.cb47c8bf.svg"
  },
  {
    "revision": "fc563797b5d4dad9f97cc96dbb7e73c8",
    "url": "localhost:5000/static/media/mx.fc563797.svg"
  },
  {
    "revision": "5991a60d506f7dff3c8c5aad18755a47",
    "url": "localhost:5000/static/media/my.5991a60d.svg"
  },
  {
    "revision": "c52af28edb1430a5e22ee2b298c86f2a",
    "url": "localhost:5000/static/media/my.c52af28e.svg"
  },
  {
    "revision": "1044789cd1ad77a7c37d8cad963dcd04",
    "url": "localhost:5000/static/media/mz.1044789c.svg"
  },
  {
    "revision": "e8801c33d8204a7ffa94fc0dcf3596d9",
    "url": "localhost:5000/static/media/mz.e8801c33.svg"
  },
  {
    "revision": "05f127b04c4f59ded6048a65a9755f13",
    "url": "localhost:5000/static/media/na.05f127b0.svg"
  },
  {
    "revision": "2a5f6f2b12334e8e742ff50ff4ce5ca2",
    "url": "localhost:5000/static/media/na.2a5f6f2b.svg"
  },
  {
    "revision": "0dba674e34d031aa3f55ad682fb7db24",
    "url": "localhost:5000/static/media/nc.0dba674e.svg"
  },
  {
    "revision": "b6c1c6b3a086590ca3a627860d0f63d1",
    "url": "localhost:5000/static/media/nc.b6c1c6b3.svg"
  },
  {
    "revision": "b7369ec74cd2a2ccf698ab0416ba2711",
    "url": "localhost:5000/static/media/ne.b7369ec7.svg"
  },
  {
    "revision": "e56edd30b77ac6f1cae9bf153b1f9ec7",
    "url": "localhost:5000/static/media/ne.e56edd30.svg"
  },
  {
    "revision": "82cb457affa8dbc92d613c757ff9ddf0",
    "url": "localhost:5000/static/media/nf.82cb457a.svg"
  },
  {
    "revision": "8f8df7a2569c67b8a13f035bfe60e92b",
    "url": "localhost:5000/static/media/nf.8f8df7a2.svg"
  },
  {
    "revision": "520463e155c2f4a38079df87c20a0423",
    "url": "localhost:5000/static/media/ng.520463e1.svg"
  },
  {
    "revision": "992459a3d0f22849b493a540e1564bb0",
    "url": "localhost:5000/static/media/ng.992459a3.svg"
  },
  {
    "revision": "b828dceb2ed17972a58379486d52c9d3",
    "url": "localhost:5000/static/media/ni.b828dceb.svg"
  },
  {
    "revision": "c90e4163df5c3a680181ce863e10bc1f",
    "url": "localhost:5000/static/media/ni.c90e4163.svg"
  },
  {
    "revision": "9bfd784cc633d04cc5f358a816085af4",
    "url": "localhost:5000/static/media/nl.9bfd784c.svg"
  },
  {
    "revision": "e336d50a0531bb958fa92165c55ff083",
    "url": "localhost:5000/static/media/nl.e336d50a.svg"
  },
  {
    "revision": "0b41df77e951a30bbfccfd0a3714a1a3",
    "url": "localhost:5000/static/media/no.0b41df77.svg"
  },
  {
    "revision": "b7a21f544f617a59abff3dac02d9101b",
    "url": "localhost:5000/static/media/no.b7a21f54.svg"
  },
  {
    "revision": "3ce0600ca4d79b3fb47aa964fc4dcc99",
    "url": "localhost:5000/static/media/np.3ce0600c.svg"
  },
  {
    "revision": "a754e9e8e0d385e0cbc31ac1bef500d5",
    "url": "localhost:5000/static/media/np.a754e9e8.svg"
  },
  {
    "revision": "2ef5b7c8f28f9c85d7c2da25b825ba5f",
    "url": "localhost:5000/static/media/nr.2ef5b7c8.svg"
  },
  {
    "revision": "34ed2f24b50edf07808df2d0917363a7",
    "url": "localhost:5000/static/media/nr.34ed2f24.svg"
  },
  {
    "revision": "4a4641b3a3309eaa1b6841b346d85ffa",
    "url": "localhost:5000/static/media/nu.4a4641b3.svg"
  },
  {
    "revision": "caaabfca4613ea4e884c7d5dd92fc628",
    "url": "localhost:5000/static/media/nu.caaabfca.svg"
  },
  {
    "revision": "380c4a3a4ec8da2aaae7e98751b6e1e7",
    "url": "localhost:5000/static/media/nz.380c4a3a.svg"
  },
  {
    "revision": "a8f100c79b238a528c1cf9640f609322",
    "url": "localhost:5000/static/media/nz.a8f100c7.svg"
  },
  {
    "revision": "397d3f2b9cb371836f79e970628eab11",
    "url": "localhost:5000/static/media/om.397d3f2b.svg"
  },
  {
    "revision": "7332c94cc6d893097dd3ff6d962a9520",
    "url": "localhost:5000/static/media/om.7332c94c.svg"
  },
  {
    "revision": "0d16b0e8d8769ea32bc60c91491a6759",
    "url": "localhost:5000/static/media/pa.0d16b0e8.svg"
  },
  {
    "revision": "beb40ab6cce7b2d196d2d4eb94848625",
    "url": "localhost:5000/static/media/pa.beb40ab6.svg"
  },
  {
    "revision": "3777e89e375c7ce2926b85051eeeec63",
    "url": "localhost:5000/static/media/pe.3777e89e.svg"
  },
  {
    "revision": "4fb8c00609a28dbedb5113f8903d403a",
    "url": "localhost:5000/static/media/pe.4fb8c006.svg"
  },
  {
    "revision": "8e525621c88b974fb4ce23ad5eaf26ef",
    "url": "localhost:5000/static/media/pf.8e525621.svg"
  },
  {
    "revision": "a68f0f63a6036a071912cc724b68742e",
    "url": "localhost:5000/static/media/pf.a68f0f63.svg"
  },
  {
    "revision": "9b228e6c353c0b8526b527863a803ca0",
    "url": "localhost:5000/static/media/pg.9b228e6c.svg"
  },
  {
    "revision": "e3c208b910d2461947b3dcee89eb8133",
    "url": "localhost:5000/static/media/pg.e3c208b9.svg"
  },
  {
    "revision": "03c78e38a895fc103769dd3e1cbe1d6a",
    "url": "localhost:5000/static/media/ph.03c78e38.svg"
  },
  {
    "revision": "4e44ea60eb7a1ebb6c0288161bfbb9a1",
    "url": "localhost:5000/static/media/ph.4e44ea60.svg"
  },
  {
    "revision": "3238f8e2bdaefa2a62b837a3c516b557",
    "url": "localhost:5000/static/media/pk.3238f8e2.svg"
  },
  {
    "revision": "3a1264711c7dbaeeff3c9a68d1fa5ac6",
    "url": "localhost:5000/static/media/pk.3a126471.svg"
  },
  {
    "revision": "3fe3bd51a504e4239ca5adaeb17a1651",
    "url": "localhost:5000/static/media/pl.3fe3bd51.svg"
  },
  {
    "revision": "562edca5bb39d66f4c9238a36295187b",
    "url": "localhost:5000/static/media/pl.562edca5.svg"
  },
  {
    "revision": "1e97e8d76fe2d553eedddc23f833bfe5",
    "url": "localhost:5000/static/media/pm.1e97e8d7.svg"
  },
  {
    "revision": "89993b1ff27bb0107946d29ffebcfcfa",
    "url": "localhost:5000/static/media/pm.89993b1f.svg"
  },
  {
    "revision": "2d4ce20974609ea74c8c6176a6b9bbde",
    "url": "localhost:5000/static/media/pn.2d4ce209.svg"
  },
  {
    "revision": "3b9532b71c6c9fc76cf5e6718ddacfb4",
    "url": "localhost:5000/static/media/pn.3b9532b7.svg"
  },
  {
    "revision": "1d278b022fba04fb58b4ed40b7562ae0",
    "url": "localhost:5000/static/media/pr.1d278b02.svg"
  },
  {
    "revision": "b55721a59f693ffb8690234d56c218cf",
    "url": "localhost:5000/static/media/pr.b55721a5.svg"
  },
  {
    "revision": "07005a7fd06016e6ceadc545e3296f7a",
    "url": "localhost:5000/static/media/ps.07005a7f.svg"
  },
  {
    "revision": "2992f9b92974b68d8a59bdcc30bfd63f",
    "url": "localhost:5000/static/media/ps.2992f9b9.svg"
  },
  {
    "revision": "09cd4ef9ba4cd30ef4628216bfd5caee",
    "url": "localhost:5000/static/media/pt.09cd4ef9.svg"
  },
  {
    "revision": "c31a6c496e2c66def3f6dd80ac80e710",
    "url": "localhost:5000/static/media/pt.c31a6c49.svg"
  },
  {
    "revision": "005061a12212476b40148b18e89739fd",
    "url": "localhost:5000/static/media/pw.005061a1.svg"
  },
  {
    "revision": "8207f6249da98267d859282dd4ed7e65",
    "url": "localhost:5000/static/media/pw.8207f624.svg"
  },
  {
    "revision": "13233f64e8bc61551916a3ba4e2c710c",
    "url": "localhost:5000/static/media/py.13233f64.svg"
  },
  {
    "revision": "c5bbbec11160887362f45012cff44f55",
    "url": "localhost:5000/static/media/py.c5bbbec1.svg"
  },
  {
    "revision": "78909a6f9bc32e8d2bb779b121cb0630",
    "url": "localhost:5000/static/media/qa.78909a6f.svg"
  },
  {
    "revision": "b314986b75f2a81f557544f73e2cd203",
    "url": "localhost:5000/static/media/qa.b314986b.svg"
  },
  {
    "revision": "01fea3b62ac2440a5785d9de95dbc3d9",
    "url": "localhost:5000/static/media/re.01fea3b6.svg"
  },
  {
    "revision": "17909e3784b7d4ef90efeae63ef194b4",
    "url": "localhost:5000/static/media/re.17909e37.svg"
  },
  {
    "revision": "22278e1314d8e81440639fe8d1e6061a",
    "url": "localhost:5000/static/media/ro.22278e13.svg"
  },
  {
    "revision": "625aca9e928c0eb9f463099945b9b115",
    "url": "localhost:5000/static/media/ro.625aca9e.svg"
  },
  {
    "revision": "0b9d64b2f235138bd7da1187d40b8eb3",
    "url": "localhost:5000/static/media/rs.0b9d64b2.svg"
  },
  {
    "revision": "14899009a0b2aec429196760ff14c448",
    "url": "localhost:5000/static/media/rs.14899009.svg"
  },
  {
    "revision": "0cacf46e6f473fa88781120f370d6107",
    "url": "localhost:5000/static/media/ru.0cacf46e.svg"
  },
  {
    "revision": "e3ee3b099783ef393f2f4dabdc75d5bc",
    "url": "localhost:5000/static/media/ru.e3ee3b09.svg"
  },
  {
    "revision": "7fe5146baf52818fc8f0845a0b36d3da",
    "url": "localhost:5000/static/media/rw.7fe5146b.svg"
  },
  {
    "revision": "997fe41bfffc77e0073f10d589ae6d27",
    "url": "localhost:5000/static/media/rw.997fe41b.svg"
  },
  {
    "revision": "01b40f18ecddca75f50f6a3471b2af25",
    "url": "localhost:5000/static/media/sa.01b40f18.svg"
  },
  {
    "revision": "02710800a40dda55c6b77fdc9d3eb654",
    "url": "localhost:5000/static/media/sa.02710800.svg"
  },
  {
    "revision": "c23eab6d60cb87d15c513db36b08fe63",
    "url": "localhost:5000/static/media/sb.c23eab6d.svg"
  },
  {
    "revision": "d64e984857cd493cbe1176acaba792a4",
    "url": "localhost:5000/static/media/sb.d64e9848.svg"
  },
  {
    "revision": "30759b7aada6d9489543086f1e388fbe",
    "url": "localhost:5000/static/media/sc.30759b7a.svg"
  },
  {
    "revision": "ad1bcb4c714e0ca8c7355ecd4b0c3cbb",
    "url": "localhost:5000/static/media/sc.ad1bcb4c.svg"
  },
  {
    "revision": "7ab061d859c16996f2bd42f650274f8e",
    "url": "localhost:5000/static/media/sd.7ab061d8.svg"
  },
  {
    "revision": "9b0974f16dc3e254519c26f9414d9a41",
    "url": "localhost:5000/static/media/sd.9b0974f1.svg"
  },
  {
    "revision": "b039bdb8e50c968b6c50c8110676061f",
    "url": "localhost:5000/static/media/se.b039bdb8.svg"
  },
  {
    "revision": "fe725901338e5651e1429ef0b241538a",
    "url": "localhost:5000/static/media/se.fe725901.svg"
  },
  {
    "revision": "45fb3666e5f08303c564532a00e88afa",
    "url": "localhost:5000/static/media/sg.45fb3666.svg"
  },
  {
    "revision": "ae32bb355a409636967840f82a26e0bc",
    "url": "localhost:5000/static/media/sg.ae32bb35.svg"
  },
  {
    "revision": "50626aa71bf595c0c0c9cc659c4be8db",
    "url": "localhost:5000/static/media/sh.50626aa7.svg"
  },
  {
    "revision": "73751467467171c36dd477eb9bad97e8",
    "url": "localhost:5000/static/media/sh.73751467.svg"
  },
  {
    "revision": "8be67718e83099e4c3310672b6555906",
    "url": "localhost:5000/static/media/si.8be67718.svg"
  },
  {
    "revision": "fb87a78663039fc23f32cebebbc19805",
    "url": "localhost:5000/static/media/si.fb87a786.svg"
  },
  {
    "revision": "ae547dbec390990657f9d8acd33fbea4",
    "url": "localhost:5000/static/media/sj.ae547dbe.svg"
  },
  {
    "revision": "ecbc9e939c3823f82f4ffa804f7d4dd4",
    "url": "localhost:5000/static/media/sj.ecbc9e93.svg"
  },
  {
    "revision": "1da1c0abd4c671c9cf2446e880ad2bcf",
    "url": "localhost:5000/static/media/sk.1da1c0ab.svg"
  },
  {
    "revision": "e7c5539e3b7e3dec8dc71f48a7614720",
    "url": "localhost:5000/static/media/sk.e7c5539e.svg"
  },
  {
    "revision": "ddbd1d9b113b2688102f56c63a431475",
    "url": "localhost:5000/static/media/sl.ddbd1d9b.svg"
  },
  {
    "revision": "f6315f743d7d62adc0f130ec0b4d13a5",
    "url": "localhost:5000/static/media/sl.f6315f74.svg"
  },
  {
    "revision": "9591e46a702f0f8f036e9e59b362f84b",
    "url": "localhost:5000/static/media/sm.9591e46a.svg"
  },
  {
    "revision": "f1d07953e03ce42c723da59b9c1c52f4",
    "url": "localhost:5000/static/media/sm.f1d07953.svg"
  },
  {
    "revision": "5b654e1a7246e45c6577b66c7b935620",
    "url": "localhost:5000/static/media/sn.5b654e1a.svg"
  },
  {
    "revision": "d2bec7efb0241ffa5077b53dae7e54a1",
    "url": "localhost:5000/static/media/sn.d2bec7ef.svg"
  },
  {
    "revision": "28889c60642fd3d81b003fb3d308d2f1",
    "url": "localhost:5000/static/media/so.28889c60.svg"
  },
  {
    "revision": "c1561217671d8bdde531130cc9997d03",
    "url": "localhost:5000/static/media/so.c1561217.svg"
  },
  {
    "revision": "788f3e2af54fdedc56e32d20777fcf5b",
    "url": "localhost:5000/static/media/sr.788f3e2a.svg"
  },
  {
    "revision": "be27d1ae7006588ccd01ae8083081944",
    "url": "localhost:5000/static/media/sr.be27d1ae.svg"
  },
  {
    "revision": "67001d2a8840b34f8407526c30a399d5",
    "url": "localhost:5000/static/media/ss.67001d2a.svg"
  },
  {
    "revision": "e3933b4455dc06b90bba00e59fba0f59",
    "url": "localhost:5000/static/media/ss.e3933b44.svg"
  },
  {
    "revision": "1f545eb99b323d22b91e51b9e56df808",
    "url": "localhost:5000/static/media/st.1f545eb9.svg"
  },
  {
    "revision": "d0a56dbbee36540ebf27ff196ea1626f",
    "url": "localhost:5000/static/media/st.d0a56dbb.svg"
  },
  {
    "revision": "46858d61ae1bdfbb547f0fd8e46486b5",
    "url": "localhost:5000/static/media/sv.46858d61.svg"
  },
  {
    "revision": "4dd6d709841ff46dc6cb62043a9046d9",
    "url": "localhost:5000/static/media/sv.4dd6d709.svg"
  },
  {
    "revision": "73a3a178768304ec82fe58b4b53ebead",
    "url": "localhost:5000/static/media/sx.73a3a178.svg"
  },
  {
    "revision": "788763923582f724fa11e480f0fb6bb6",
    "url": "localhost:5000/static/media/sx.78876392.svg"
  },
  {
    "revision": "64f0d2d7a590e22c8d0c415ba7d729af",
    "url": "localhost:5000/static/media/sy.64f0d2d7.svg"
  },
  {
    "revision": "73690f50d6d4106fbd4c8ac3a556b985",
    "url": "localhost:5000/static/media/sy.73690f50.svg"
  },
  {
    "revision": "c8d5c2d9c0e8849271af0664df052817",
    "url": "localhost:5000/static/media/sygnet.c8d5c2d9.svg"
  },
  {
    "revision": "1e261ba080ba07a0f96d4e62b607a89d",
    "url": "localhost:5000/static/media/sz.1e261ba0.svg"
  },
  {
    "revision": "fa1a994d9c1fcf5c559ea963c3e529d7",
    "url": "localhost:5000/static/media/sz.fa1a994d.svg"
  },
  {
    "revision": "c3867f8dbaf12f6ceb7bdac49a858485",
    "url": "localhost:5000/static/media/tc.c3867f8d.svg"
  },
  {
    "revision": "c61ef06abf4474b5d2af370c6b90589c",
    "url": "localhost:5000/static/media/tc.c61ef06a.svg"
  },
  {
    "revision": "a0923ddc3c8abed20bfdfbd559c8d7b0",
    "url": "localhost:5000/static/media/td.a0923ddc.svg"
  },
  {
    "revision": "f37a395c81f2cfe3b51e5f254970b8b7",
    "url": "localhost:5000/static/media/td.f37a395c.svg"
  },
  {
    "revision": "2e7dc1af2d97ea62c34756b7f838fa77",
    "url": "localhost:5000/static/media/tf.2e7dc1af.svg"
  },
  {
    "revision": "4ab43cc9db2814759ac2990c761f60a3",
    "url": "localhost:5000/static/media/tf.4ab43cc9.svg"
  },
  {
    "revision": "29fa137c095a6ace1adc5d8de4a19309",
    "url": "localhost:5000/static/media/tg.29fa137c.svg"
  },
  {
    "revision": "e602a907e1228d0fc75e6278e916e13d",
    "url": "localhost:5000/static/media/tg.e602a907.svg"
  },
  {
    "revision": "76fca72f6d180d3f14a55653b8937b5e",
    "url": "localhost:5000/static/media/th.76fca72f.svg"
  },
  {
    "revision": "904dd7853b623153a82acf5c4abd297b",
    "url": "localhost:5000/static/media/th.904dd785.svg"
  },
  {
    "revision": "09418f138f5581e3c49a750001b5b700",
    "url": "localhost:5000/static/media/tj.09418f13.svg"
  },
  {
    "revision": "9853139b446ddf94d5f1dde4fc2d397f",
    "url": "localhost:5000/static/media/tj.9853139b.svg"
  },
  {
    "revision": "1959d9de338fea49559ebcdbc11d7185",
    "url": "localhost:5000/static/media/tk.1959d9de.svg"
  },
  {
    "revision": "7aaccddb93a504f69855f07491550439",
    "url": "localhost:5000/static/media/tk.7aaccddb.svg"
  },
  {
    "revision": "0616faaafebb8abad85242c3b67f7ec5",
    "url": "localhost:5000/static/media/tl.0616faaa.svg"
  },
  {
    "revision": "7942bccbe6f775c88769deca528b85ab",
    "url": "localhost:5000/static/media/tl.7942bccb.svg"
  },
  {
    "revision": "64aa750d7b27817b8d1fd0c71d065c29",
    "url": "localhost:5000/static/media/tm.64aa750d.svg"
  },
  {
    "revision": "bdd29cb93d94d36b6d3dcf4dff99024f",
    "url": "localhost:5000/static/media/tm.bdd29cb9.svg"
  },
  {
    "revision": "440d3505fe97c32cac8929ba17c45e36",
    "url": "localhost:5000/static/media/tn.440d3505.svg"
  },
  {
    "revision": "89a384a0709264d3f4b9b8d37f627189",
    "url": "localhost:5000/static/media/tn.89a384a0.svg"
  },
  {
    "revision": "238ef1cd63bf158a8679f40a3fd2ae4d",
    "url": "localhost:5000/static/media/to.238ef1cd.svg"
  },
  {
    "revision": "79354e72ad0559ef82e28d0f2e88033f",
    "url": "localhost:5000/static/media/to.79354e72.svg"
  },
  {
    "revision": "ce2e2e8e0650cfed7548dd59c2c184c5",
    "url": "localhost:5000/static/media/tr.ce2e2e8e.svg"
  },
  {
    "revision": "ed6d5f37779af38911b0b7cb2212e30d",
    "url": "localhost:5000/static/media/tr.ed6d5f37.svg"
  },
  {
    "revision": "27c618af43e3f072906916a4fafc98d1",
    "url": "localhost:5000/static/media/tt.27c618af.svg"
  },
  {
    "revision": "c3647d9bc890d2ebd383b80a3812e52f",
    "url": "localhost:5000/static/media/tt.c3647d9b.svg"
  },
  {
    "revision": "d78bd31e5a11723db4d4ca9a01075817",
    "url": "localhost:5000/static/media/tv.d78bd31e.svg"
  },
  {
    "revision": "f4b7afec4d58a73acc185cdcd045c4eb",
    "url": "localhost:5000/static/media/tv.f4b7afec.svg"
  },
  {
    "revision": "21291ae9738c4cdacdac9d5da4bbf702",
    "url": "localhost:5000/static/media/tw.21291ae9.svg"
  },
  {
    "revision": "eb5ac13798e16da73d0e7425d20b0e74",
    "url": "localhost:5000/static/media/tw.eb5ac137.svg"
  },
  {
    "revision": "d02545a1e6ca8ee2c217c28e7c44dedc",
    "url": "localhost:5000/static/media/tz.d02545a1.svg"
  },
  {
    "revision": "d3df42da90c6a077c532fad041b2246e",
    "url": "localhost:5000/static/media/tz.d3df42da.svg"
  },
  {
    "revision": "841d259d582b4c6f5585da31b4aab774",
    "url": "localhost:5000/static/media/ua.841d259d.svg"
  },
  {
    "revision": "a8b13525ee3b82f901196668f4733097",
    "url": "localhost:5000/static/media/ua.a8b13525.svg"
  },
  {
    "revision": "1c8fcdc4a4d91ad1ead179ad0af49c0f",
    "url": "localhost:5000/static/media/ug.1c8fcdc4.svg"
  },
  {
    "revision": "278e456e685ba419e2b3baed28100daa",
    "url": "localhost:5000/static/media/ug.278e456e.svg"
  },
  {
    "revision": "05615112706e0396ff8c91eb9b6c05f2",
    "url": "localhost:5000/static/media/um.05615112.svg"
  },
  {
    "revision": "3d347682d5c526a37719f5ab8a890f11",
    "url": "localhost:5000/static/media/um.3d347682.svg"
  },
  {
    "revision": "3835716fbdb5281c231d2f31a29738bf",
    "url": "localhost:5000/static/media/un.3835716f.svg"
  },
  {
    "revision": "c366cfa86e7874f3155d1a1763b8b46a",
    "url": "localhost:5000/static/media/un.c366cfa8.svg"
  },
  {
    "revision": "8ec583188aba7e9426580350312d97a5",
    "url": "localhost:5000/static/media/us.8ec58318.svg"
  },
  {
    "revision": "ae65659236a7e348402799477237e6fa",
    "url": "localhost:5000/static/media/us.ae656592.svg"
  },
  {
    "revision": "79b02850081e27b3ba209e6ae60ad50f",
    "url": "localhost:5000/static/media/uy.79b02850.svg"
  },
  {
    "revision": "adbc4992aa0cb87499df3323234076f3",
    "url": "localhost:5000/static/media/uy.adbc4992.svg"
  },
  {
    "revision": "ca892343cb962d42bc4cc36d776d63e8",
    "url": "localhost:5000/static/media/uz.ca892343.svg"
  },
  {
    "revision": "eb1e00b870d7f0784288d76eb3bfc1d5",
    "url": "localhost:5000/static/media/uz.eb1e00b8.svg"
  },
  {
    "revision": "0e3b3cc1a9ecdad8993aa9068279c25b",
    "url": "localhost:5000/static/media/va.0e3b3cc1.svg"
  },
  {
    "revision": "56a808f752bba8da66f93cd5cbffbd2d",
    "url": "localhost:5000/static/media/va.56a808f7.svg"
  },
  {
    "revision": "4ac5124fbf60fcff6808515904a79f04",
    "url": "localhost:5000/static/media/vc.4ac5124f.svg"
  },
  {
    "revision": "bbb52fa0756298590332a07e5d69f2c2",
    "url": "localhost:5000/static/media/vc.bbb52fa0.svg"
  },
  {
    "revision": "9f23d9626b92963d5502674c91463b51",
    "url": "localhost:5000/static/media/ve.9f23d962.svg"
  },
  {
    "revision": "b2cd5a9a011fd43f115a2c5e2c9f91e5",
    "url": "localhost:5000/static/media/ve.b2cd5a9a.svg"
  },
  {
    "revision": "68763b7f309901d80c3e6a3bddccd165",
    "url": "localhost:5000/static/media/vg.68763b7f.svg"
  },
  {
    "revision": "e1c461f74da3c3a9c03312dfbc7c8bce",
    "url": "localhost:5000/static/media/vg.e1c461f7.svg"
  },
  {
    "revision": "9af6bfa678419ab72df48c3bf8449fc0",
    "url": "localhost:5000/static/media/vi.9af6bfa6.svg"
  },
  {
    "revision": "b41b18d98e3931a28af0fb4b145ca0eb",
    "url": "localhost:5000/static/media/vi.b41b18d9.svg"
  },
  {
    "revision": "a0081482192375c70656860e843b3c8d",
    "url": "localhost:5000/static/media/vn.a0081482.svg"
  },
  {
    "revision": "a62ad62f354af546c5d9df10b183f995",
    "url": "localhost:5000/static/media/vn.a62ad62f.svg"
  },
  {
    "revision": "5c33b1e789de1ff9e75e660e485f7b20",
    "url": "localhost:5000/static/media/vu.5c33b1e7.svg"
  },
  {
    "revision": "9b6cbbe930942b2cef6c4479119524a5",
    "url": "localhost:5000/static/media/vu.9b6cbbe9.svg"
  },
  {
    "revision": "05522b9f19236d09cc79eee2588b6992",
    "url": "localhost:5000/static/media/wf.05522b9f.svg"
  },
  {
    "revision": "e3ac728c6286182ecee6047ba2d84627",
    "url": "localhost:5000/static/media/wf.e3ac728c.svg"
  },
  {
    "revision": "3ea6d44f91f0accab1ba37b5b7a80f55",
    "url": "localhost:5000/static/media/ws.3ea6d44f.svg"
  },
  {
    "revision": "405a2c5f036343f54f0e46ab054e7cf8",
    "url": "localhost:5000/static/media/ws.405a2c5f.svg"
  },
  {
    "revision": "2750d8e7e2952ec3d3ddcf2e0197071e",
    "url": "localhost:5000/static/media/xk.2750d8e7.svg"
  },
  {
    "revision": "de2602071a8fce352950a01cfaecd4ca",
    "url": "localhost:5000/static/media/xk.de260207.svg"
  },
  {
    "revision": "b5840a84dc1fc44424947f817a83b8ce",
    "url": "localhost:5000/static/media/ye.b5840a84.svg"
  },
  {
    "revision": "d13e1629bdb0f80baef6f33d88503231",
    "url": "localhost:5000/static/media/ye.d13e1629.svg"
  },
  {
    "revision": "b6042b9cfb432f844e964ddb24b4f341",
    "url": "localhost:5000/static/media/yt.b6042b9c.svg"
  },
  {
    "revision": "f06d254d5978e4b0223fa242514e55e1",
    "url": "localhost:5000/static/media/yt.f06d254d.svg"
  },
  {
    "revision": "67ff2e108ce38abcf3f68b4e1ba3c7af",
    "url": "localhost:5000/static/media/za.67ff2e10.svg"
  },
  {
    "revision": "70a290afe3dffa54924e7ddffd767687",
    "url": "localhost:5000/static/media/za.70a290af.svg"
  },
  {
    "revision": "71bdc28b46f99807803f1785bf8a4e2a",
    "url": "localhost:5000/static/media/zm.71bdc28b.svg"
  },
  {
    "revision": "b7864d5c330b306eb3d2106725690e5f",
    "url": "localhost:5000/static/media/zm.b7864d5c.svg"
  },
  {
    "revision": "a21f533de8561217cb8c0792d82a0bcc",
    "url": "localhost:5000/static/media/zw.a21f533d.svg"
  },
  {
    "revision": "ad4ad36d51c5c76a774f3bb11a2f0e99",
    "url": "localhost:5000/static/media/zw.ad4ad36d.svg"
  }
]);